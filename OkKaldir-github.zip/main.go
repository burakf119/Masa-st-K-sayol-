package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"syscall"
	"unsafe"
)

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	advapi32 = syscall.NewLazyDLL("advapi32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")

	pMessageBox     = user32.NewProc("MessageBoxW")
	pRegCreateKeyEx = advapi32.NewProc("RegCreateKeyExW")
	pRegSetValueEx  = advapi32.NewProc("RegSetValueExW")
	pRegDeleteValue = advapi32.NewProc("RegDeleteValueW")
	pRegCloseKey    = advapi32.NewProc("RegCloseKey")
	pShellExecute   = shell32.NewProc("ShellExecuteW")
)

const (
	hklm       = 0x80000002
	keyAccess  = 0x0002 | 0x0100 // KEY_SET_VALUE | KEY_WOW64_64KEY
	regSZ      = 1
	keyPath    = `SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons`
	title      = "Ok Kaldır"
	mbOK       = 0x0
	mbYesNoCan = 0x3
	mbQuestion = 0x20
	mbInfo     = 0x40
	mbError    = 0x10
	idYes      = 6
	idNo       = 7
)

func u(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }

func msg(text string, flags uintptr) int {
	r, _, _ := pMessageBox.Call(0, uintptr(unsafe.Pointer(u(text))), uintptr(unsafe.Pointer(u(title))), flags)
	return int(r)
}

func openKey() (syscall.Handle, bool) {
	var h syscall.Handle
	r, _, _ := pRegCreateKeyEx.Call(hklm, uintptr(unsafe.Pointer(u(keyPath))), 0, 0, 0, keyAccess, 0, uintptr(unsafe.Pointer(&h)), 0)
	return h, r == 0
}

// 32x32, tamamen şeffaf ikon
func blankIco() []byte {
	b := []byte{0, 0, 1, 0, 1, 0, // ICONDIR
		32, 32, 0, 0, 1, 0, 32, 0, // w,h,colors,res,planes,bpp
		0xA8, 0x10, 0, 0, // boyut: 40+4096+128 = 4264
		22, 0, 0, 0, // offset
		40, 0, 0, 0, 32, 0, 0, 0, 64, 0, 0, 0, 1, 0, 32, 0, // BITMAPINFOHEADER
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
	b = append(b, make([]byte, 4096)...)
	for i := 0; i < 128; i++ {
		b = append(b, 0xFF)
	}
	return b
}

func run(name string, args ...string) {
	c := exec.Command(name, args...)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	c.Run()
}

func restartExplorer() {
	run("taskkill", "/f", "/im", "explorer.exe")
	if la := os.Getenv("LOCALAPPDATA"); la != "" {
		os.Remove(filepath.Join(la, "IconCache.db"))
		m, _ := filepath.Glob(filepath.Join(la, `Microsoft\Windows\Explorer\iconcache_*.db`))
		for _, f := range m {
			os.Remove(f)
		}
	}
	exec.Command(filepath.Join(os.Getenv("WINDIR"), "explorer.exe")).Start()
}

func main() {
	h, ok := openKey()
	if !ok {
		// Yönetici değiliz: kendimizi yönetici olarak yeniden başlat
		exe, _ := os.Executable()
		pShellExecute.Call(0, uintptr(unsafe.Pointer(u("runas"))), uintptr(unsafe.Pointer(u(exe))), 0, 0, 1)
		return
	}
	defer pRegCloseKey.Call(uintptr(h))

	r := msg("Masaüstü ikonlarındaki kısayol oklarını ne yapalım?\n\n"+
		"EVET  →  Okları kaldır\n"+
		"HAYIR  →  Okları geri getir\n"+
		"İPTAL  →  Çık\n\n"+
		"Not: Masaüstü birkaç saniyeliğine kapanıp açılır.", mbYesNoCan|mbQuestion)

	switch r {
	case idYes:
		dir := filepath.Join(os.Getenv("ProgramData"), "OkKaldir")
		os.MkdirAll(dir, 0755)
		ico := filepath.Join(dir, "blank.ico")
		if err := os.WriteFile(ico, blankIco(), 0644); err != nil {
			msg("Boş ikon dosyası yazılamadı:\n"+err.Error(), mbError)
			return
		}
		val, _ := syscall.UTF16FromString(ico + ",0")
		rc, _, _ := pRegSetValueEx.Call(uintptr(h), uintptr(unsafe.Pointer(u("29"))), 0, regSZ,
			uintptr(unsafe.Pointer(&val[0])), uintptr(len(val)*2))
		if rc != 0 {
			msg("Kayıt defterine yazılamadı.", mbError)
			return
		}
		restartExplorer()
		msg("Kısayol okları kaldırıldı.", mbInfo)
	case idNo:
		pRegDeleteValue.Call(uintptr(h), uintptr(unsafe.Pointer(u("29"))))
		restartExplorer()
		msg("Kısayol okları geri getirildi.", mbInfo)
	}
}
